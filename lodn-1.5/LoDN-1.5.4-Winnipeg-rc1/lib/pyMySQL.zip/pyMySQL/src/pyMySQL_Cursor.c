#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Python.h"
#include "structmember.h"
#include "datetime.h"
#include "mysql.h"

#include "pyMySQL.h"



static void pyMySQL_CursorObject_dealloc(pyMySQL_CursorObject *self)
{
	/* Decrements the reference count on the ConnectionObject */
	Py_XDECREF(self->connObj);

	Py_XDECREF(self->description);
	Py_XDECREF(self->rowcount);
	Py_XDECREF(self->arraysize);

	if(self->mysqlResultSet != NULL && self->resultSetFinished == 0)
	{
		mysql_free_result(self->mysqlResultSet);
		self->mysqlResultSet = NULL;
	}

	/* Frees the actual object */
    Py_TYPE(self)->tp_free((PyObject*)self);
}


pyMySQL_CursorObject *pyMySQL_CursorObject_NEW(void)
{
	/* Declarations */
	pyMySQL_CursorObject *self;


	/* Allocates a cursor object */
	if((self = (pyMySQL_CursorObject*)pyMySQL_CursorType.tp_new(
									&pyMySQL_CursorType, NULL, NULL)) == NULL)
	{
		return NULL;
	}

	/* Initializes the cursor object and on error frees it */
	if(pyMySQL_CursorType.tp_init((PyObject*)self, NULL, NULL) != 0)
	{
		Py_DECREF(self);
		return NULL;
	}

	/* Return a reference to the new Cursor Object */
	return self;
}



static PyObject *pyMySQL_CursorObject_new(PyTypeObject *type,
												PyObject *args, PyObject *kwds)
{
	/* Declarations */
    pyMySQL_CursorObject *self;


    /* Allocates an instance of pyMySQL_ConnectionObject */
    self = (pyMySQL_CursorObject*)(type->tp_alloc(type, 0));

    self->connObj 	 	 = NULL;
    self->mysqlResultSet = NULL;
    self->resultSetFinished = 0;


    Py_INCREF(Py_None);
    self->description = Py_None;

    Py_INCREF(Py_None);
    self->rowcount = Py_None;

    Py_INCREF(Py_None);
    self->arraysize = Py_None;

    /* Returns the object */
    return (PyObject*)self;
}


static int pyMySQL_CursorObject_init(pyMySQL_CursorObject *self,
											PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	PyObject *tmpRowCount = NULL;
	PyObject *tmpArraySize = NULL;


	/* Checks the provides args */
	if(args != NULL)
	{
		if(!PyArg_ParseTuple(args, ""))
		{
			return -1;
		}
	}

	/* Initializes the row count */
	if((tmpRowCount = PyLong_FromLong(-1)) == NULL)
	{
		goto ERROR_HANDLER;
	}

	/* Initialize the array size */
	if((tmpArraySize = PyLong_FromLong(1)) == NULL)
	{
		goto ERROR_HANDLER;
	}


	/* Initializes the connObj */
	Py_INCREF(Py_None);
	Py_XDECREF(self->connObj);
	self->connObj = (pyMySQL_ConnectionObject*)Py_None;


	/* Sets up description */
	Py_INCREF(Py_None);
	Py_DECREF(self->description);
	self->description = Py_None;

	/* Sets up rowcount */
	Py_DECREF(self->rowcount);
	self->rowcount = tmpRowCount;

	/* Sets up array size */
	Py_DECREF(self->arraysize);
	self->arraysize = tmpArraySize;

	self->mysqlResultSet = NULL;
	self->resultSetFinished = 0;

	/* Return success */
	return 0;

	/* Error handler */
	ERROR_HANDLER:

		Py_XDECREF(tmpRowCount);
		Py_XDECREF(tmpArraySize);

		return -1;
}

static PyObject *pyMySQL_CursorObject_close(pyMySQL_CursorObject *self)
{
	/* Decrements the reference count on the ConnectionObject */
	Py_XDECREF(self->connObj);

	/* Sets the connObj to NULL */
	self->connObj = NULL;

	if(self->mysqlResultSet != NULL)
	{
		mysql_free_result(self->mysqlResultSet);
		self->mysqlResultSet = NULL;
	}

	self->resultSetFinished = 1;


	/* Frees description */
	Py_INCREF(Py_None);
	Py_DECREF(self->description);
	self->description = Py_None;

	/* Resets the rowcount */
	Py_DECREF(self->rowcount);
	if((self->rowcount = PyLong_FromLong(-1)) == NULL)
	{
		return NULL;
	}

	/* Returns None */
	Py_RETURN_NONE;
}


static inline int _pyMySQL_parameter_convert(MYSQL *conn, PyObject *paraObj,
					char **base, int *offset, int *max_length)
{
	/* Declarations */
	PyObject *stringObj      = NULL;
	PyObject *asciiStringObj = NULL;
	PyObject *bytesObj		 = NULL;
	char     *buffer		 = NULL;
	Py_ssize_t length;
	PyObject *exception 	= NULL;
	char 	 *errorString 	= NULL;
	PyObject *errorTuple;


	/* String type */
	if(PyUnicode_CheckExact(paraObj))
	{
		if((asciiStringObj = PyUnicode_AsASCIIString(paraObj)) == NULL)
		{
			exception = pyMySQL_OperationalError;
			errorString = "Bad string conversion";
			goto FINALLY;
		}

		if((bytesObj = PyBytes_FromObject(asciiStringObj)) == NULL)
		{
			exception = pyMySQL_OperationalError;
			errorString =  "Bad string conversion";
			goto FINALLY;
		}

		if(PyBytes_AsStringAndSize(bytesObj, &buffer, &length) != 0)
		{
			exception = pyMySQL_OperationalError;
			errorString = "Bad string conversion";
			goto FINALLY;
		}

		length += 3;

		if((*offset + length) >= *max_length)
		{
			*max_length = (*offset) + length;

			//*max_length = (*offset) + length*2+3;

			if((*base = PyMem_Realloc(*base, *max_length)) == NULL)
			{
				PyErr_NoMemory();
				goto FINALLY;
			}
		}

		snprintf((*base)+(*offset), length, "'%s'", buffer);

		*offset += length-1;

		/*(*base)[*offset] = '\'';
		*offset += 1;
		length = mysql_real_escape_string(conn, (*base)+(*offset), buffer, length);
		*offset += length;

		(*base)[*offset] = '\'';
		*offset += 1;*/


	/* Binary */
	}else if(PyBytes_CheckExact(paraObj))
	{
		if(PyBytes_AsStringAndSize(paraObj, &buffer, &length) != 0)
		{
			exception = pyMySQL_ProgrammingError;
			errorString = "Bad string conversion";
			goto FINALLY;
		}

		if((*offset + length*2+1) >= *max_length)
		{
			*max_length = (*offset) + length*2+1;

			if((*base = PyMem_Realloc(*base, *max_length)) == NULL)
			{
				PyErr_NoMemory();
				goto FINALLY;
			}
		}

		length = mysql_real_escape_string(conn, (*base)+(*offset), buffer, length);

		*offset += length;

	/* NULL type */
	}else if(paraObj == Py_None)
	{
		buffer = "NULL";
		length = strlen(buffer);
		length += 1;

		if((*offset + length) >= *max_length)
		{
			*max_length = (*offset) + length;

			if((*base = PyMem_Realloc(*base, *max_length)) == NULL)
			{
				PyErr_NoMemory();
				goto FINALLY;
			}
		}

		snprintf((*base)+(*offset), length, "%s", buffer);

		*offset += length-1;

	/* Numeric value */
	}else if(PyLong_Check(paraObj) || PyFloat_Check(paraObj))
	{
		if((stringObj = PyObject_Str(paraObj)) == NULL)
		{
			exception = pyMySQL_OperationalError;
			errorString = "Bad numeric conversion";
			goto FINALLY;
		}

		if((asciiStringObj = PyUnicode_AsASCIIString(stringObj)) == NULL)
		{
			exception = pyMySQL_OperationalError;
			errorString = "Bad numeric conversion";
			goto FINALLY;
		}

		if((bytesObj   = PyBytes_FromObject(asciiStringObj)) == NULL)
		{
			exception = pyMySQL_OperationalError;
			errorString = "Bad numeric conversion";
			goto FINALLY;
		}

		if(PyBytes_AsStringAndSize(bytesObj, &buffer, &length) != 0)
		{
			exception = pyMySQL_OperationalError;
			errorString = "Bad numeric conversion";
			goto FINALLY;
		}

		length += 1;

		if((*offset + length) >= *max_length)
		{
			*max_length = (*offset) + length;

			if((*base = PyMem_Realloc(*base, *max_length)) == NULL)
			{
				PyErr_NoMemory();
				goto FINALLY;
			}
		}

		snprintf((*base)+(*offset), length, "%s", buffer);

		*offset += length-1;


	/* Date */
	}else
	{
		PyDateTime_IMPORT;
		/* Time objects are converted here */
		if(PyDate_CheckExact(paraObj) || PyTime_CheckExact(paraObj) ||
				PyDateTime_CheckExact(paraObj))
		{
			if((stringObj = PyObject_Str(paraObj)) == NULL)
			{
				exception = pyMySQL_OperationalError;
				errorString = "Bad date/time conversion";
				goto FINALLY;
			}

			if((asciiStringObj = PyUnicode_AsASCIIString(stringObj)) == NULL)
			{
				exception = pyMySQL_OperationalError;
				errorString = "Bad date/time conversion";
				goto FINALLY;
			}

			if((bytesObj   = PyBytes_FromObject(asciiStringObj)) == NULL)
			{
				exception = pyMySQL_OperationalError;
				errorString = "Bad date/time conversion";
				goto FINALLY;
			}

			if(PyBytes_AsStringAndSize(bytesObj, &buffer, &length) != 0)
			{
				exception = pyMySQL_OperationalError;
				errorString = "Bad date/time conversion";
				goto FINALLY;
			}

			length += 3;

			if((*offset + length) >= *max_length)
			{
				*max_length = (*offset) + length;

				if((*base = PyMem_Realloc(*base, *max_length)) == NULL)
				{
					PyErr_NoMemory();
					goto FINALLY;
				}
			}

			snprintf((*base)+(*offset), length, "'%s'", buffer);

			*offset += length-1;

		}else
		{
			exception = pyMySQL_ProgrammingError;
			errorString = "Invalid type given as parameter";
			goto FINALLY;
		}
	}


	/* Finally clause */
	FINALLY:

		/* Frees the string object */
		if(stringObj != NULL)
		{
			Py_DECREF(stringObj);
		}

		/* Frees the ascii string object */
		if(asciiStringObj != NULL)
		{
			Py_DECREF(asciiStringObj);
		}

		/* Frees the bytes object */
		if(bytesObj != NULL)
		{
			Py_DECREF(bytesObj);
		}

		/* Regular python exception has occurred */
		if(PyErr_Occurred())
		{
			return -1;

		/* Error in converting within this function has occurred */
		}else if(exception != NULL)
		{
			if((errorTuple = Py_BuildValue("i s", 0, errorString)) == NULL)
			{
				PyErr_NoMemory();
				return -1;
			}

			PyErr_SetObject(exception, errorTuple);
			Py_DECREF(errorTuple);

			return -1;
		}

		/* Success */
		return 0;
}


static inline char *_pyMySQL_parameter_string(MYSQL *conn, char *input_string,
											  int length,
											  PyObject *parametersObject)
{
	/* Declarations */
	PyObject *parameterObject = NULL;
	PyObject *exception = NULL;
	PyObject *errorTuple;
	char 	 *errorString;
	char *output_string;
	int   numParameters=0;
	int   output_length;
	int   i;
	int   j;
	int   p = 0;



	/* Holds the number of parameters */
	if(parametersObject != NULL)
	{
		numParameters = PySequence_Size(parametersObject);
	}

	output_length = length;

	/* Allocates a new cstring for the expression */
	if((output_string = PyMem_Malloc(output_length)) == NULL)
	{
		PyErr_NoMemory();
		return NULL;
	}

	/* Iterates over the input string handling parameters */
	for(i=0, j=0; i<length && input_string[i] != '\0'; i++)
	{
		/* Parameter */
		if(input_string[i] == '?')
		{
			/* Checks that there is a parameter in the input tuple */
			if(p >= numParameters)
			{
				exception = pyMySQL_ProgrammingError;
				errorString = "Incorrect number of parameters supplied";

				goto ERROR_HANDLER;
			}

			/* Grabs the parameter from the input tuple */
			if((parameterObject = PySequence_GetItem(parametersObject, p)) == NULL)
			{
				goto ERROR_HANDLER;
			}

			/* Adds the parameter to the output string */
			if(_pyMySQL_parameter_convert(conn, parameterObject,
								&output_string, &j, &output_length) != 0)
			{
				goto ERROR_HANDLER;
			}

			p++;

		/* Normal char */
		}else
		{
			/* Checks if the output string needs to be reallocated (doubled
			 * in size) */
			if(output_length <= (j+1))
			{
				output_length *= 2 + 1;
				if((output_string = PyMem_Realloc(output_string, output_length)) == NULL)
				{
					PyErr_NoMemory();
					goto ERROR_HANDLER;
				}
			}

			/* Copies the current character into the output string */
			output_string[j] = input_string[i];
			j++;
		}
	}

	/* Ends the output string */
	output_string[j] = '\0';

	/* Checks if all of the parameters were consumed */
	if(numParameters != p)
	{
		exception = pyMySQL_ProgrammingError;
		errorString = "Incorrect number of parameters supplied";
		goto ERROR_HANDLER;
	}



	/* Returns the output string */
	return output_string;


	/* Error Handler */
	ERROR_HANDLER:

		PyMem_Free(output_string);

		if(!PyErr_Occurred())
		{
			if((errorTuple = Py_BuildValue("i s", 0, errorString)) == NULL)
			{
				PyErr_NoMemory();
				return NULL;
			}

			PyErr_SetObject(exception, errorTuple);
			Py_DECREF(errorTuple);
		}

		return NULL;
}


static PyObject *_pyMySQL_description_helper(MYSQL_RES *result)
{
	/* Declarations */
	unsigned int num_fields;
	unsigned int i;
	MYSQL_FIELD *fields;

	PyObject *description = NULL;
	PyObject *fieldDescription;
	PyObject *name;
	PyObject *type_code;


	/* Gets the fields and the number of fields */
	num_fields = mysql_num_fields(result);
	fields     = mysql_fetch_fields(result);



	if((description = PyTuple_New(num_fields)) == NULL)
	{
		goto ERROR_HANDLER;
	}


	for(i = 0; i < num_fields; i++)
	{
		if((fieldDescription = PyTuple_New(7)) == NULL)
		{
			goto ERROR_HANDLER;
		}

		if((name = PyUnicode_FromString(fields[i].name)) == NULL)
		{
			goto ERROR_HANDLER;
		}

		if((type_code = PyLong_FromLong(fields[i].type)) == NULL)
		{
			Py_DECREF(name);
			goto ERROR_HANDLER;
		}

		if(PyTuple_SetItem(fieldDescription, 0, name) != 0)
		{
			Py_DECREF(name);
			Py_DECREF(type_code);
			goto ERROR_HANDLER;
		}

		if(PyTuple_SetItem(fieldDescription, 1, type_code) != 0)
		{
			Py_DECREF(type_code);
			goto ERROR_HANDLER;
		}

		if(PyTuple_SetItem(fieldDescription, 2, Py_None) != 0)
		{
			goto ERROR_HANDLER;
		}

		Py_INCREF(Py_None);

		if(PyTuple_SetItem(fieldDescription, 3, Py_None) != 0)
		{
			goto ERROR_HANDLER;
		}

		Py_INCREF(Py_None);

		if(PyTuple_SetItem(fieldDescription, 4, Py_None) != 0)
		{
			goto ERROR_HANDLER;
		}

		Py_INCREF(Py_None);

		if(PyTuple_SetItem(fieldDescription, 5, Py_None) != 0)
		{
			goto ERROR_HANDLER;
		}

		Py_INCREF(Py_None);

		if(PyTuple_SetItem(fieldDescription, 6, Py_None) != 0)
		{
			goto ERROR_HANDLER;
		}

		Py_INCREF(Py_None);

		if(PyTuple_SetItem(description, i, fieldDescription) != 0)
		{
			goto ERROR_HANDLER;
		}

		Py_INCREF(Py_None);
	}

	/* Return the description tuple of the fields */
	return description;

	/* Error handler */
	ERROR_HANDLER:

		Py_XDECREF(fieldDescription);

		Py_XDECREF(description);

		return NULL;
}


static int _pyMySQL_CursorObject_execute_helper(pyMySQL_CursorObject *self,
				char *stmt_str, int stmt_str_length, PyObject *parameterObject)
{
	/* Declarations */
	PyThreadState *_save;


	if((stmt_str = _pyMySQL_parameter_string(self->connObj->conn, stmt_str,
											stmt_str_length,
											parameterObject)) == NULL)
	{
		return -1;
	}

	/* Increment the reference count to ensure that after gil is turned off
	 * these objects don't disappear */
	Py_INCREF(self);
	Py_INCREF(self->connObj);

	/* Turn threads block off */
	_save = PyEval_SaveThread();


	/* Executes the SQL statement */
	if(mysql_real_query(self->connObj->conn, stmt_str, strlen(stmt_str)) != 0)
	{
		PyEval_RestoreThread(_save);
		Py_DECREF(self->connObj);
		Py_DECREF(self);
		PyMem_Free(stmt_str);
		return -1;
	}

	/* Sets up the result set for later recall */
	self->mysqlResultSet = mysql_store_result(self->connObj->conn);
	while(self->mysqlResultSet == NULL && mysql_more_results(self->connObj->conn))
	{
		mysql_next_result(self->connObj->conn);
		self->mysqlResultSet = mysql_store_result(self->connObj->conn);
	}


	/* Turn thread block on */
	PyEval_RestoreThread(_save);

	/* Decrement the reference count on the threads */
	Py_DECREF(self->connObj);
	Py_DECREF(self);

	/* Free the string */
	PyMem_Free(stmt_str);

	/* Return successfully */
	return 0;
}


PyObject *pyMySQL_CursorObject_execute(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	char *stmt_str;
	int stmt_str_length;
	PyObject  *parameterObject = NULL;
	PyObject *tmpDescription = NULL;
	PyObject *tmpAffectedRows = NULL;


	/* Checks that the cursor is still open */
	if(self->connObj == NULL)
	{
		PyObject *errorTuple;

		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Gets the arguments to the method.  */
	if(!PyArg_ParseTuple(args, "s#|O", &stmt_str, &stmt_str_length,
										&parameterObject))
	{
		return NULL;
	}

	/* If provided, this checks that the second argument supports the sequence
	 * protocol */
	if(parameterObject != NULL)
	{
		if(PySequence_Check(parameterObject) != 1)
		{
			PyErr_SetString(PyExc_TypeError,
					"Argument 2 must support the sequence protocol");
			return NULL;
		}
	}


	if(self->mysqlResultSet != NULL && self->resultSetFinished == 0)
	{
		mysql_free_result(self->mysqlResultSet);
		self->mysqlResultSet = NULL;
	}

	/* Sets up description */
	Py_INCREF(Py_None);
	Py_DECREF(self->description);
	self->description = Py_None;


	/* Does the actual execution */
	if(_pyMySQL_CursorObject_execute_helper(self, stmt_str, stmt_str_length,
											parameterObject) != 0)
	{
		goto ERROR_HANDLER;
	}

	if(self->mysqlResultSet == NULL)
	{
		if(mysql_errno(self->connObj->conn) != 0)
		{
			goto ERROR_HANDLER;
		}

		tmpDescription = self->description;
		Py_INCREF(tmpDescription);

	/* Queriable results */
	}else
	{
		if((tmpDescription = _pyMySQL_description_helper(self->mysqlResultSet))
				== NULL)
		{
			goto ERROR_HANDLER;
		}
	}

	self->resultSetFinished = 0;

	/* Gets the number of affected rows */
	if((tmpAffectedRows = PyLong_FromLongLong(mysql_affected_rows(
			self->connObj->conn))) == NULL)
	{
		goto ERROR_HANDLER;
	}

	/* Assigns the description tuple */
	Py_DECREF(self->description);
	self->description = tmpDescription;

	/* Assigns the affected rows */
	Py_DECREF(self->rowcount);
	self->rowcount = tmpAffectedRows;


	/* Returns None */
	Py_RETURN_NONE;


	/* Error handler */
	ERROR_HANDLER:

		Py_XDECREF(tmpDescription);
		Py_XDECREF(tmpAffectedRows);

		pyMySQL_set_exception(self->connObj->conn);

		/* Return that an error has occurred */
		return NULL;
}


PyObject *pyMySQL_CursorObject_executemany(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	PyObject *sequenceOfParameters;
	PyObject *parameterObjects;
	PyObject *tmpDescription = NULL;
	PyObject *tmpAffectedRows = NULL;
	PyObject *errorTuple;
	char *stmt_str;
	int   stmt_str_length;
	Py_ssize_t numOfSequences;
	Py_ssize_t i;
	my_ulonglong numAffectedRows = 0;


	/* Checks that the cursor is still open */
	if(self->connObj == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Gets the arguments to the method.  */
	if(!PyArg_ParseTuple(args, "s#|O", &stmt_str, &stmt_str_length,
										&sequenceOfParameters))
	{
		return NULL;
	}

	/* This checks that the second argument supports the sequence protocol */
	if(PySequence_Check(sequenceOfParameters) != 1)
	{
		PyErr_SetString(PyExc_TypeError,
				"Argument 2 must support the sequence protocol");
		return NULL;
	}

	/* Gets the number of parameter sequences */
	numOfSequences = PySequence_Size(sequenceOfParameters);

	/* Checks that each item in is also a sequence */
	for(i=0; i<numOfSequences; i++)
	{
		if(PySequence_Check(PySequence_GetItem(sequenceOfParameters, i)) != 1)
		{
			PyErr_SetString(PyExc_TypeError,
							"Argument 2 must be a sequences of sequences");
			return NULL;
		}
	}

	/* Frees the current result set if there is one */
	if(self->mysqlResultSet != NULL && self->resultSetFinished == 0)
	{
		mysql_free_result(self->mysqlResultSet);
		self->mysqlResultSet = NULL;
	}

	/* Sets up description */
	Py_INCREF(Py_None);
	Py_DECREF(self->description);
	self->description = Py_None;

	/* Does a execute for each parameter object */
	for(i=0; i<numOfSequences; i++)
	{
		/* Gets the current parameter */
		parameterObjects = PySequence_GetItem(sequenceOfParameters, i);

		/* Executes the sql statment with the parameters */
		if(_pyMySQL_CursorObject_execute_helper(self, stmt_str, stmt_str_length,
				parameterObjects) != 0)
		{
			goto ERROR_HANDLER;
		}

		/* This method does not allow for result results */
		if(self->mysqlResultSet != NULL)
		{
			if((errorTuple = Py_BuildValue("i s", 0,
				"executemany method is not allowed to return a result set."))
				 == NULL)
			{
				PyErr_NoMemory();
				goto ERROR_HANDLER;
			}

			PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
			Py_DECREF(errorTuple);

			goto ERROR_HANDLER;
		}

		/* Gets the number of affected rows for this execute */
		numAffectedRows += mysql_affected_rows(self->connObj->conn);
	}

	self->resultSetFinished = 0;

	/* Gets the number of affected rows */
	if((tmpAffectedRows = PyLong_FromLongLong(numAffectedRows)) == NULL)
	{
		goto ERROR_HANDLER;
	}

	/* Assigns the affected rows */
	Py_DECREF(self->rowcount);
	self->rowcount = tmpAffectedRows;


	/* Return successfully */
	Py_RETURN_NONE;

	/* Error handler */
	ERROR_HANDLER:

		/* Error handler */
		if(self->mysqlResultSet != NULL)
		{
			mysql_free_result(self->mysqlResultSet);
			self->mysqlResultSet = NULL;
			self->resultSetFinished = 0;
		}

		/* Decrements tmpAffectedRows reference count */
		Py_XDECREF(tmpAffectedRows);

		/* Sets an the exception if no error has been set thus far */
		if(!PyErr_Occurred())
		{
			pyMySQL_set_exception(self->connObj->conn);
		}

		/* Return error */
		return NULL;
}





PyObject *pyMySQL_CursorObject_executescript(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	char *stmt_str;
	int stmt_str_length;
	PyObject  *parameterObject = NULL;
	PyObject *tmpDescription = NULL;
	PyObject *tmpAffectedRows = NULL;
	PyObject *errorTuple;


	/* Checks that the cursor is still open */
	if(self->connObj == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Gets the arguments to the method.  */
	if(!PyArg_ParseTuple(args, "s#", &stmt_str, &stmt_str_length))
	{
		return NULL;
	}

	if(self->mysqlResultSet != NULL && self->resultSetFinished == 0)
	{
		mysql_free_result(self->mysqlResultSet);
		self->mysqlResultSet = NULL;
	}

	/* Sets up description */
	Py_INCREF(Py_None);
	Py_DECREF(self->description);
	self->description = Py_None;

	/* Does the actual execution */
	if(_pyMySQL_CursorObject_execute_helper(self, stmt_str, stmt_str_length,
											NULL) != 0)
	{
		goto ERROR_HANDLER;
	}

	if(self->mysqlResultSet == NULL)
	{
		if(mysql_errno(self->connObj->conn) != 0)
		{
			goto ERROR_HANDLER;
		}

		tmpDescription = self->description;
		Py_INCREF(tmpDescription);

	/* Queriable results */
	}else
	{
		if((tmpDescription = _pyMySQL_description_helper(self->mysqlResultSet))
				== NULL)
		{
			goto ERROR_HANDLER;
		}
	}

	self->resultSetFinished = 0;

	/* Gets the number of affected rows */
	if((tmpAffectedRows = PyLong_FromLongLong(mysql_affected_rows(
			self->connObj->conn))) == NULL)
	{
		goto ERROR_HANDLER;
	}

	/* Assigns the description tuple */
	Py_DECREF(self->description);
	self->description = tmpDescription;

	/* Assigns the affected rows */
	Py_DECREF(self->rowcount);
	self->rowcount = tmpAffectedRows;



	/* Return successfully */
	Py_RETURN_NONE;


	ERROR_HANDLER:

		/* Error handler */
		if(self->mysqlResultSet != NULL)
		{
			mysql_free_result(self->mysqlResultSet);
			self->mysqlResultSet = NULL;
			self->resultSetFinished = 0;
		}

		/* Decrements tmpAffectedRows reference count */
		Py_XDECREF(tmpAffectedRows);

		/* Sets an the exception if no error has been set thus far */
		if(!PyErr_Occurred())
		{
			pyMySQL_set_exception(self->connObj->conn);
		}

		return NULL;
}

PyObject *pyMySQL_CursorObject_callproc(pyMySQL_CursorObject *self,
										PyObject *args)
{
	/* Declarations */
	char *procname;
	int   procname_len;
	PyObject *parametersObj = NULL;
	int   numParameters;
	PyObject *tmpDescription = NULL;
	PyObject *tmpAffectedRows = NULL;
	PyObject *errorTuple;


	/* Checks that the cursor is still open */
	if(self->connObj == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Parses the args */
	if(!PyArg_ParseTuple(args, "s#|O", &procname, &procname_len, &parametersObj))
	{
		return NULL;
	}

	/* Checks the sequence type */
	if(parametersObj != NULL)
	{
		if(!PySequence_Check(parametersObj))
		{
			PyErr_SetString(PyExc_TypeError,
							"Argument 2 must support the sequence protocol");
			return NULL;
		}

		/* Gets the number of parameters */
		numParameters = PySequence_Length(parametersObj);

	/* No parameters */
	}else
	{
		numParameters = 0;
	}


	/* Frees the current result set if there is one */
	if(self->mysqlResultSet != NULL && self->resultSetFinished == 0)
	{
		mysql_free_result(self->mysqlResultSet);
		self->mysqlResultSet = NULL;
	}


#define PROCEDURE_CALL		"CALL"

	char *callstr = NULL;
	size_t callstr_len;
	int i;

	/* Calculates the length of the call string */
	callstr_len = strlen(PROCEDURE_CALL) + strlen(procname) +
								numParameters*3*sizeof(char) + 16;

	/* Allocates a call str */
	if((callstr = PyMem_Malloc(callstr_len)) == NULL)
	{
		PyErr_NoMemory();
		return NULL;
	}

	/* Builds the initial call string */
	sprintf(callstr, "%s %s (", PROCEDURE_CALL, procname);

	if(numParameters > 0)
	{
		for(i=0; i<numParameters-1; i++)
		{
			strcat(callstr, "?, ");
		}

		strcat(callstr, "?");
	}

	strcat(callstr, ")");


	/* Sets up description */
	Py_INCREF(Py_None);
	Py_DECREF(self->description);
	self->description = Py_None;

	/* Does the actual execution */
	if(_pyMySQL_CursorObject_execute_helper(self, callstr, callstr_len,
											parametersObj) != 0)
	{
		goto ERROR_HANDLER;
	}

	if(self->mysqlResultSet == NULL)
	{
		if(mysql_errno(self->connObj->conn) != 0)
		{
			goto ERROR_HANDLER;
		}

		tmpDescription = self->description;
		Py_INCREF(tmpDescription);

	/* Queriable results */
	}else
	{
		if((tmpDescription = _pyMySQL_description_helper(self->mysqlResultSet))
				== NULL)
		{
			goto ERROR_HANDLER;
		}
	}

	self->resultSetFinished = 0;

	/* Gets the number of affected rows */
	if((tmpAffectedRows = PyLong_FromLongLong(mysql_affected_rows(
			self->connObj->conn))) == NULL)
	{
		goto ERROR_HANDLER;
	}

	/* Assigns the description tuple */
	Py_DECREF(self->description);
	self->description = tmpDescription;

	/* Assigns the affected rows */
	Py_DECREF(self->rowcount);
	self->rowcount = tmpAffectedRows;

	/* Frees the allocated c string */
	PyMem_Free(callstr);

	/* Returns None */
	Py_RETURN_NONE;


	/* Error handler */
	ERROR_HANDLER:

		/* Frees the allocated string */
		if(callstr != NULL)
		{
			PyMem_Free(callstr);
		}

		/* Frees the description and affected rows */
		Py_XDECREF(tmpDescription);
		Py_XDECREF(tmpAffectedRows);

		/* Sets an exception */
		pyMySQL_set_exception(self->connObj->conn);

		/* Return error */
		return NULL;
}


static inline PyObject *_pyMySQL_CursorObject_fetchhelper(pyMySQL_CursorObject *self)
{
	/* Decarations */
	PyObject 	*tmpAffectedRows;
	PyObject 	*tmpDescription;
	MYSQL_ROW 		mysqlRow;
	MYSQL_FIELD    *mysqlFields;
	unsigned int 	numFields;
	unsigned long  *fieldLengths;
	PyObject       *fieldObj = NULL;
	PyObject       *retTuple = NULL;
	unsigned int    i;


	/* Result is done and freed so just return NULL */
	if(self->resultSetFinished == 1)
	{
		Py_RETURN_NONE;
	}


	/* Fetches the next row */
	mysqlRow = mysql_fetch_row(self->mysqlResultSet);


	/* Either an error has occurred or out of data */
	if(mysqlRow == NULL)
	{
		/* Mark the result set finished and free it */
		self->resultSetFinished = 1;
		mysql_free_result(self->mysqlResultSet);
		self->mysqlResultSet = NULL;

		/* Out of data */
		if(mysql_errno(self->connObj->conn) == 0)
		{
			Py_RETURN_NONE;

		/* Error has occurred */
		}else
		{
			pyMySQL_set_exception(self->connObj->conn);
			return NULL;
		}
	}


//	/* Either an error has occurred or out of data */
//	while(mysqlRow == NULL)
//	{
//		/* Mark the result set finished and free it */
//		self->resultSetFinished = 1;
//		mysql_free_result(self->mysqlResultSet);
//		self->mysqlResultSet = NULL;
//
//		/* Check for next result set */
//		switch(mysql_next_result(self->connObj->conn))
//		{
//			/* More results */
//			case 0:
//
//				if((self->mysqlResultSet = mysql_store_result(
//							self->connObj->conn)) == NULL)
//				{
//					if(mysql_errno(self->connObj->conn) != 0)
//					{
//						pyMySQL_set_exception(self->connObj->conn);
//						return NULL;
//					}else
//					{
//						Py_RETURN_NONE;
//					}
//				}
//
//				/* Fetches the next row */
//				if((mysqlRow = mysql_fetch_row(self->mysqlResultSet)) == NULL)
//				{
//					break;
//				}
//
//				/* Gets the number of affected rows */
//				if((tmpAffectedRows = PyLong_FromLongLong(mysql_affected_rows(
//							self->connObj->conn))) == NULL)
//				{
//					if(!PyErr_Occurred()) PyErr_NoMemory();
//					return NULL;
//				}
//
//				/* Gets the description */
//				if((tmpDescription = _pyMySQL_description_helper(
//						self->mysqlResultSet)) == NULL)
//				{
//					Py_DECREF(tmpAffectedRows);
//					if(!PyErr_Occurred()) PyErr_NoMemory();
//					return NULL;
//				}
//
//				/* Assigns the description tuple */
//				Py_DECREF(self->description);
//				self->description = tmpDescription;
//
//				/* Assigns the affected rows */
//				Py_DECREF(self->rowcount);
//				self->rowcount = tmpAffectedRows;
//
//
//				self->resultSetFinished = 0;
//
//				break;
//
//			/* No more results */
//			case -1:
//
//				/* Out of data */
//				if(mysql_errno(self->connObj->conn) == 0)
//				{
//					Py_RETURN_NONE;
//
//				/* Error has occurred */
//				}else
//				{
//					pyMySQL_set_exception(self->connObj->conn);
//					return NULL;
//				}
//
//				break;
//
//			/* Error has occurred */
//			default:
//
//				pyMySQL_set_exception(self->connObj->conn);
//				return NULL;
//		}
//	}

	/* Gets the number of fields, the fields and their lengths */
	numFields		= mysql_num_fields(self->mysqlResultSet);
	mysqlFields 	= mysql_fetch_fields(self->mysqlResultSet);
	fieldLengths 	= mysql_fetch_lengths(self->mysqlResultSet);


	/* Makes a tuple to hold the row of fields */
	if((retTuple = PyTuple_New(numFields)) == NULL)
	{
		return NULL;
	}

	/* Traverses the fields of the row */
	for(i=0; i<numFields; i++)
	{
		/* Converts the field into a Python Object */
		if((fieldObj = pyMySQL_SQLTypeToPyObject(&mysqlFields[i], mysqlRow[i],
				fieldLengths[i])) == NULL)
		{
			goto ERROR_HANDLER;
		}

		/* Adds the field object to the return tuple */
		if(PyTuple_SetItem(retTuple, i, fieldObj) != 0)
		{
			goto ERROR_HANDLER;
		}

		fieldObj = NULL;
	}

	/* Return tuple */
	return retTuple;


	/* Error handler */
	ERROR_HANDLER:

		/* Frees the tuple */
		if(retTuple != NULL)
		{
			/* Frees the last fieldObj if its not already in the list */
			if(fieldObj != NULL)
			{
				if(PyTuple_GetItem(retTuple, PyTuple_Size(retTuple)-1) != fieldObj)
				{
					Py_DECREF(fieldObj);
				}
			}

			Py_DECREF(retTuple);
		}


		/* Indicate failure */
		return NULL;
}



static PyObject *pyMySQL_CursorObject_fetchone(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	PyObject *errorTuple;


	/* Checks that the cursor is still open */
	if(self->connObj == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
						"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* No outstanding queries */
	if(self->mysqlResultSet == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot retrieve row after non query.")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Uses the fetch helper to return a tuple of the next row, None if its out
	 * or NULL on error */
	return _pyMySQL_CursorObject_fetchhelper(self);
}


static PyObject *pyMySQL_CursorObject_fetchmany(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	PyTupleObject 		 *retTuple 	= NULL;
	PyTupleObject		 *rowTuple  = NULL;
	PyObject             *errorTuple;
	Py_ssize_t 			  size;
	Py_ssize_t			  i;
	int 				  keepGoing;


	/* Sets the default size */
	size = PyLong_AsSsize_t(self->arraysize);

	/* Parses the args */
	if(!PyArg_ParseTuple(args, "|n", &size))
	{
		return NULL;
	}

	/* Checks that the cursor is still open */
	if(self->connObj == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* No outstanding queries */
	if(self->mysqlResultSet == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot retrieve row after non query.")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	if((retTuple = (PyTupleObject*)PyTuple_New(size)) == NULL)
	{
		return NULL;
	}

	/* Builds a tuple of all the row tuples until either size or the list has
	 * been exhaused */
	for(i=0, keepGoing=1; i<size && keepGoing; i++)
	{
		rowTuple = (PyTupleObject*)_pyMySQL_CursorObject_fetchhelper(self);

		/* End of list */
		if((PyObject*)rowTuple == Py_None)
		{
			keepGoing = 0;

		/* Error has occurred */
		}else if(rowTuple == NULL)
		{
			goto ERROR_HANDLER;

		/* Add the row tuple to the tuple */
		}else
		{
			if(PyTuple_SetItem((PyObject*)retTuple, i, (PyObject*)rowTuple) != 0)
			{
				goto ERROR_HANDLER;
			}
		}
	}

	/* Adjusts the tuple size to its final size */
	if(!keepGoing)
	{
		if(_PyTuple_Resize((PyObject**)&retTuple, i-1) == -1)
		{
			goto ERROR_HANDLER;
		}
	}

	/* Returns the tuple of rows */
	return (PyObject*)retTuple;


	/* Error Handler */
	ERROR_HANDLER:

		if(retTuple != NULL)
		{
			/* Free the row tuple if its not in the list */
			if(rowTuple != NULL)
			{
				if(PyTuple_GetItem((PyObject*)retTuple,
					PyTuple_Size((PyObject*)retTuple)-1) != (PyObject*)rowTuple)
				{
					Py_DECREF(rowTuple);
				}
			}

			/* Free the retTuple */
			Py_DECREF(retTuple);
		}

		/* Indicate error */
		return NULL;
}

static PyObject *pyMySQL_CursorObject_fetchall(pyMySQL_CursorObject *self)
{
	/* Declarations */
	PyTupleObject 		 *retTuple 	= NULL;
	PyTupleObject		 *rowTuple  = NULL;
	PyObject             *errorTuple;
	PyListObject *rowList = NULL;


	/* Checks that the cursor is still open */
	if(self->connObj == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}


		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* No outstanding queries */
	if(self->mysqlResultSet == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot retrieve row after non query.")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}


		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Creates a list to hold the rows temporarily */
	if((rowList = (PyListObject*)PyList_New(0)) == NULL)
	{
		return NULL;
	}

	/* Builds a list of all of the remaining sql rows */
	do
	{
		/* Gets a tuple row */
		rowTuple = (PyTupleObject*)_pyMySQL_CursorObject_fetchhelper(self);

		/* Error has occurred */
		if(rowTuple == NULL)
		{
			goto ERROR_HANDLER;

		/* Adds the row tuple to the list */
		}else if(rowTuple != (PyTupleObject*)Py_None)
		{
			if(PyList_Append((PyObject*)rowList, (PyObject*)rowTuple) != 0)
			{
				goto ERROR_HANDLER;
			}

			/* Decrements the rowTuple reference since the list will be done
			 * away with shortly */
			Py_DecRef((PyObject*)rowTuple);
		}

	}while(rowTuple != (PyTupleObject*)Py_None);

	/* Builds a tuple from the list to return */
	if((retTuple = (PyTupleObject*)PyList_AsTuple((PyObject*)rowList)) == NULL)
	{
		goto ERROR_HANDLER;
	}

	/* Frees the row list */
	Py_DECREF(rowList);

	/* Returns a tuple of the rows */
	return (PyObject*)retTuple;


	/* Error handler */
	ERROR_HANDLER:

		if(rowList != NULL)
		{
			Py_DECREF(rowList);

			if(retTuple != NULL)
			{
				Py_DECREF(retTuple);
			}
		}

		return NULL;
}


static PyObject *pyMySQL_CursorObject_nextset(pyMySQL_CursorObject *self)
{
	/* Declarations */
	PyObject *retObj;
	PyObject *errorTuple;



	/* Checks that the cursor is still open */
	if(self->connObj == NULL)
	{
		if((errorTuple == Py_BuildValue("i s", 0,
						"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* No current result set */
	if(self->mysqlResultSet == NULL)
	{
		/* No sets are left */
		if(self->resultSetFinished)
		{
			if(mysql_more_results(self->connObj->conn))
			{
				while(self->mysqlResultSet == NULL &&
						mysql_more_results(self->connObj->conn))
				{
					mysql_next_result(self->connObj->conn);
					self->mysqlResultSet = mysql_store_result(self->connObj->conn);
				}

				/* No result sets left */
				if(self->mysqlResultSet == NULL)
				{
					self->resultSetFinished = 1;
					retObj = Py_None;

				/* New result set */
				}else
				{
					self->resultSetFinished = 0;
					retObj = Py_True;
				}
			}

			retObj = Py_None;

		/* There were never any sets */
		}else
		{
			if((errorTuple == Py_BuildValue("i s", 0,
											"No sets available.")) == NULL)
			{
				PyErr_NoMemory();
				return NULL;
			}

			PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
			Py_DECREF(errorTuple);

			return NULL;
		}

	/* Current result set */
	}else
	{
		/* Frees the current result set */
		mysql_free_result(self->mysqlResultSet);

		/* Sets up the result set for later recall */
		self->mysqlResultSet = mysql_store_result(self->connObj->conn);
		while(self->mysqlResultSet == NULL &&
				mysql_more_results(self->connObj->conn))
		{
			mysql_next_result(self->connObj->conn);
			self->mysqlResultSet = mysql_store_result(self->connObj->conn);
		}

		/* No result sets left */
		if(self->mysqlResultSet == NULL)
		{
			self->resultSetFinished = 1;
			retObj = Py_None;

		/* New result set */
		}else
		{
			self->resultSetFinished = 0;
			retObj = Py_True;
		}
	}

	/* Return True for next set or None if result sets are exhausted */
	Py_INCREF(retObj);
	return retObj;
}


static PyObject *pyMySQL_CursorObject_setinputsizes(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds)
{
	/* Declarations */
    PyObject *sequence;


	/* Parses the args */
	if(!PyArg_ParseTuple(args, "O", &sequence))
	{
		return NULL;
	}


	/* Do nothing */

	/* Return successfully */
	Py_RETURN_NONE;
}


static PyObject *pyMySQL_CursorObject_setoutputsize(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	int size;
	int columnIndex;


	/* Parses the args */
	if(!PyArg_ParseTuple(args, "i|i", &size, &columnIndex))
	{
		return NULL;
	}

	/* Do nothing */

	/* Return successfully */
	Py_RETURN_NONE;
}


static PyObject *pyMySQL_CursorObject_getArraysize(pyMySQL_CursorObject *self,
												void *closure)
{
	Py_INCREF(self->arraysize);
	return self->arraysize;
}

static int pyMySQL_CursorObject_setArraysize(pyMySQL_CursorObject *self,
												PyObject *value, void *closure)
{
	/* Checks that the value isn't NULL */
	if(value == NULL)
	{
		PyErr_SetString(PyExc_TypeError,
							"Cannot delete the arraysize attribute");
		return -1;
	}

	/* Checks that its an integer */
	if(!PyLong_Check(value))
	{
		PyErr_SetString(PyExc_TypeError,
		                    "The arraysize attribute value must be a int");
		return -1;
	}

	/* Handles the reference counting */
	Py_INCREF(value);
	Py_DECREF(self->arraysize);

	/* Sets arraysize */
	self->arraysize = value;

	/* Returns successfully */
	return 0;
}





static PyMemberDef pyMySQL_CursorObject_members[] = {
	/*{"arraysize", T_OBJECT_EX, offsetof(pyMySQL_CursorObject, arraysize),
			0, "number of rows to fetch with fetchmany()"}, */
	{"description", T_OBJECT_EX, offsetof(pyMySQL_CursorObject, description),
			READONLY, "tuple of description"},
	{"rowcount", T_OBJECT_EX, offsetof(pyMySQL_CursorObject, rowcount),
			READONLY, "number of affected rows by the last execute* method"},
    {NULL}  /* Sentinel */
};

static PyGetSetDef pyMySQL_CursorObject_getsetters[] = {
    {"arraysize",
    		(getter)pyMySQL_CursorObject_getArraysize,
    		(setter)pyMySQL_CursorObject_setArraysize,
    		"number of rows to fetch with fetchmany()", NULL},
    {NULL}  /* Sentinel */
};


static PyMethodDef pyMySQL_CursorObject_methods[] = {
	{"close", (PyCFunction)pyMySQL_CursorObject_close, METH_NOARGS,
		"Closes the cursor"},
	{"execute", (PyCFunction)pyMySQL_CursorObject_execute, METH_VARARGS,
		"Prepare and execute a database operation"},
	{"executemany", (PyCFunction)pyMySQL_CursorObject_executemany, METH_VARARGS,
		"executes a database operation using a series of parameter sequences."},
	{"executescript", (PyCFunction)pyMySQL_CursorObject_executescript, METH_VARARGS,
		"executes a sql script statement"},
	{"callproc", (PyCFunction)pyMySQL_CursorObject_callproc, METH_VARARGS,
		"calls a procedure with the given parameters."},
	{"fetchone", (PyCFunction)pyMySQL_CursorObject_fetchone, METH_NOARGS,
		"Fetch the next row of a query set"},
	{"fetchmany", (PyCFunction)pyMySQL_CursorObject_fetchmany, METH_VARARGS,
		"Fetch the next sequence of rows of a query set"},
	{"fetchall", (PyCFunction)pyMySQL_CursorObject_fetchall, METH_NOARGS,
		"Fetch the remaining rows of a query set"},
	{"nextset", (PyCFunction)pyMySQL_CursorObject_nextset, METH_NOARGS,
		"Skips the cursor to the next set"},
	{"setinputsizes", (PyCFunction)pyMySQL_CursorObject_setinputsizes, METH_VARARGS,
		"set the sizes of the input parameters."},
	{"setoutputsize", (PyCFunction)pyMySQL_CursorObject_setoutputsize, METH_VARARGS,
		"set a column buffer size for fetches"},
    {NULL}  /* Sentinel */
};



PyTypeObject pyMySQL_CursorType = {
    PyObject_HEAD_INIT(NULL)
    "pyMySQL.Cursor",             /* tp_name */
    sizeof(pyMySQL_CursorObject), /* tp_basicsize */
    0,                         /* tp_itemsize */
    (destructor)pyMySQL_CursorObject_dealloc,     /* tp_dealloc */
    0,                         /* tp_print */
    0,                         /* tp_getattr */
    0,                         /* tp_setattr */
    0,                         /* tp_reserved */
    0,                         /* tp_repr */
    0,                         /* tp_as_number */
    0,                         /* tp_as_sequence */
    0,                         /* tp_as_mapping */
    0,                         /* tp_hash  */
    0,                         /* tp_call */
    0,                         /* tp_str */
    0,                         /* tp_getattro */
    0,                         /* tp_setattro */
    0,                         /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT |
		Py_TPFLAGS_BASETYPE,        /* tp_flags */
    NULL,			           /* tp_doc */
    0,		               /* tp_traverse */
	0,		               /* tp_clear */
	0,		               /* tp_richcompare */
	0,		               /* tp_weaklistoffset */
	0,		               /* tp_iter */
	0,		               /* tp_iternext */
	pyMySQL_CursorObject_methods,             /* tp_methods */
	pyMySQL_CursorObject_members,             /* tp_members */
	pyMySQL_CursorObject_getsetters,          /* tp_getset */
	0,                         /* tp_base */
	0,                         /* tp_dict */
	0,                         /* tp_descr_get */
	0,                         /* tp_descr_set */
	0,                         /* tp_dictoffset */
	(initproc)pyMySQL_CursorObject_init,      /* tp_init */
	0,                         /* tp_alloc */
	pyMySQL_CursorObject_new,                 /* tp_new */
};


