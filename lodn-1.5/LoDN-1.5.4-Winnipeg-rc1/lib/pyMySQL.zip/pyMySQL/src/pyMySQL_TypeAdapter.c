#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "Python.h"
#include "datetime.h"
#include "mysql.h"

#include "pyMySQL.h"


PyObject *pyMySQL_Date(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	int year;
	int month;
	int day;


	/* Gets the year, month and day for the date object */
	if(!PyArg_ParseTuple(args, "iii", &year, &month, &day))
	{
		return NULL;
	}

	PyDateTime_IMPORT;

	/* Returns a PyDate object  using the year, month and day */
	return PyDate_FromDate(year, month, day);
}



PyObject *pyMySQL_Time(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	int hour;
	int minute;
	int second;


	/* Gets the hour, minute, and second for the time object */
	if(!PyArg_ParseTuple(args, "iii", &hour, &minute, &second))
	{
		return NULL;
	}

	PyDateTime_IMPORT;

	/* Returns a Time object using the hour, minute and second */
	return PyTime_FromTime(hour, minute, second, 0);
}


PyObject *pyMySQL_Timestamp(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	int year;
	int month;
	int day;
	int hour;
	int minute;
	int second;


	/* Gets the year, month, day, hour, minute, and second for the timestamp
	 * object */
	if(!PyArg_ParseTuple(args, "iiiiii", &year, &month, &day, &hour,
							&minute, &second))
	{
		return NULL;
	}

	PyDateTime_IMPORT;

	/* Returns a DateTime object for the year, month, day, hour, minute and
	 * second that was supplied to this function. */
    return PyDateTime_FromDateAndTime(year, month, day, hour, minute, second, 0);
}


PyObject *pyMySQL_Datetime(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	int year;
	int month;
	int day;
	int hour;
	int minute;
	int second;


	/* Gets the year, month, day, hour, minute, and second for the timestamp
	 * object */
	if(!PyArg_ParseTuple(args, "iiiiii", &year, &month, &day, &hour,
							&minute, &second))
	{
		return NULL;
	}

	PyDateTime_IMPORT;

	/* Returns a DateTime object for the year, month, day, hour, minute and
	 * second that was supplied to this function. */
    return PyDateTime_FromDateAndTime(year, month, day, hour, minute, second, 0);
}


PyObject *pyMySQL_DateFromTicks(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	int ticks;
	struct tm timeField;
	PyObject *errorTuple;


	/* Gets the ticks */
	if(!PyArg_ParseTuple(args, "i", &ticks))
	{
		return NULL;
	}

	/* Converts ticks to broken up time */
	if(localtime_r((time_t*)&ticks, &timeField) == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
										"Incorrect ticks provided")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	PyDateTime_IMPORT;

	/* Returns a PyDate object  using the year, month and day */
	return PyDate_FromDate(timeField.tm_year, timeField.tm_mon,
							timeField.tm_mday);
}



PyObject *pyMySQL_TimeFromTicks(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	int ticks;
	struct tm timeField;
	PyObject *errorTuple;


	/* Gets the ticks */
	if(!PyArg_ParseTuple(args, "i", &ticks))
	{
		return NULL;
	}

	/* Converts ticks to broken up time */
	if(localtime_r((time_t*)&ticks, &timeField) == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
										"Incorrect ticks provided")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	PyDateTime_IMPORT;

	/* Returns a Time object using the hour, minute and second */
	return PyTime_FromTime(timeField.tm_hour, timeField.tm_min,
							timeField.tm_sec, 0);
}


PyObject *pyMySQL_TimestampFromTicks(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	int ticks;
	struct tm timeField;
	PyObject *errorTuple;


	/* Gets the ticks */
	if(!PyArg_ParseTuple(args, "i", &ticks))
	{
		return NULL;
	}

	/* Converts ticks to broken up time */
	if(localtime_r((time_t*)&ticks, &timeField) == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
										"Incorrect ticks provided")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	PyDateTime_IMPORT;

	/* Returns a DateTime object for the year, month, day, hour, minute and
	 * second that was supplied to this function. */
	return PyDateTime_FromDateAndTime(timeField.tm_year, timeField.tm_mon,
										timeField.tm_mday, timeField.tm_hour,
										timeField.tm_min, timeField.tm_sec, 0);
}

/*
DateFromTicks(ticks)

            This function constructs an object holding a date value
            from the given ticks value (number of seconds since the
            epoch; see the documentation of the standard Python time
            module for details).

        TimeFromTicks(ticks)

            This function constructs an object holding a time value
            from the given ticks value (number of seconds since the
            epoch; see the documentation of the standard Python time
            module for details).

        TimestampFromTicks(ticks)

            This function constructs an object holding a time stamp
            value from the given ticks value (number of seconds since
            the epoch; see the documentation of the standard Python
            time module for details).

*/

PyObject *pyMySQL_Binary(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	PyObject *obj;
	PyObject *retObj;


	/* Gets the object that was passed in */
	if(!PyArg_ParseTuple(args, "O", &obj))
	{
		return NULL;
	}

	/* If its a unicode string then it copies the data from the string otherwise
	 * it treats it as a regular object.  It crates a new byte object that
	 * holds the data */
	if(PyUnicode_Check(obj))
	{
		retObj = PyBytes_FromString(obj);
	}else
	{
		retObj = PyBytes_FromObject(obj);
	}

	/* Returns the new bytes object */
	return retObj;
}










PyObject *pyMySQL_SQLTypeToPyObject(MYSQL_FIELD *field,
							char *data, unsigned long dataLength)
{
	/* Declarations */
	PyObject *retObj = NULL;
	PyObject *pyObjStr;


	/* Check if value is NULL */
	if(dataLength == 0 && data == NULL)
	{
		Py_RETURN_NONE;
	}


	/* Handles the type */
	switch(field->type)
	{
		/* MySQL string type */
		case MYSQL_TYPE_STRING:

			retObj = PyUnicode_FromStringAndSize(data, dataLength);
			break;

		/* MySQL var string type */
		case MYSQL_TYPE_VAR_STRING:

			retObj = PyUnicode_FromStringAndSize(data, dataLength);
			break;

		/* MYSQL BLOB */
		case MYSQL_TYPE_BLOB:

			retObj = PyBytes_FromStringAndSize(data, dataLength);
			break;

		/* MySQL Tiny INT */
		case MYSQL_TYPE_TINY:

			retObj = PyLong_FromString(data, NULL, 10);
			break;

		/* MySQL SHORT INT type */
		case MYSQL_TYPE_SHORT:

			retObj = PyLong_FromString(data, NULL, 10);
			break;

		/* MySQL LONG INT type */
		case MYSQL_TYPE_LONG:

			retObj = PyLong_FromString(data, NULL, 10);
			break;

		/* MySQL 24 bit INT type */
		case MYSQL_TYPE_INT24:

			retObj = PyLong_FromString(data, NULL, 10);
			break;

		/* MySQL Long Long INT type */
		case MYSQL_TYPE_LONGLONG:

			retObj = PyLong_FromString(data, NULL, 10);
			break;

		/* DECIMAL or NUMERIC field */
		case MYSQL_TYPE_DECIMAL:

			if((pyObjStr  = PyUnicode_FromString(data)) != NULL)
			{
				retObj 	  = PyFloat_FromString(pyObjStr);
				Py_DECREF(pyObjStr);
			}

			break;

		/* Precision math DECIMAL or NUMERIC field (MySQL 5.0.3 and up) */
		case MYSQL_TYPE_NEWDECIMAL:

			if((pyObjStr  = PyUnicode_FromString(data)) != NULL)
			{
				retObj 	  = PyFloat_FromString(pyObjStr);
				Py_DECREF(pyObjStr);
			}

			break;

		/* FLOAT field */
		case MYSQL_TYPE_FLOAT:

			printf("float");
			if((pyObjStr  = PyUnicode_FromString(data)) != NULL)
			{
				retObj 	  = PyFloat_FromString(pyObjStr);
				Py_DECREF(pyObjStr);
			}

			break;

		/* DOUBLE or REAL field */
		case MYSQL_TYPE_DOUBLE:

			if((pyObjStr  = PyUnicode_FromString(data)) != NULL)
			{
				retObj 	  = PyFloat_FromString(pyObjStr);
				Py_DECREF(pyObjStr);
			}

			break;

		/* BIT field (MySQL 5.0.3 and up) */
		case MYSQL_TYPE_BIT:

			PyErr_SetString(pyMySQL_OperationalError,
							"MYSQL_TYPE_BIT is unsupported type.");
			break;

		/* TIMESTAMP field */
		case MYSQL_TYPE_TIMESTAMP:

			retObj = PyUnicode_FromString(data);
			break;

		/* DATE field */
		case MYSQL_TYPE_DATE:

			retObj = PyUnicode_FromString(data);
			break;

		/* TIME field */
		case MYSQL_TYPE_TIME:

			retObj = PyUnicode_FromString(data);
			break;

		/* DATETIME field */
		case MYSQL_TYPE_DATETIME:

			retObj = PyUnicode_FromString(data);
			break;

		/* YEAR field */
		case MYSQL_TYPE_YEAR:
			PyErr_SetString(pyMySQL_OperationalError,
							"MYSQL_TYPE_SET is unsupported type.");
			break;


		/* SET field */
		case MYSQL_TYPE_SET:
			PyErr_SetString(pyMySQL_OperationalError,
							"MYSQL_TYPE_SET is unsupported type.");
			break;

		/* ENUM field */
		case MYSQL_TYPE_ENUM:
			PyErr_SetString(pyMySQL_OperationalError,
							"MYSQL_TYPE_ENUM is unsupported type.");
			break;

		/* Spatial field */
		case MYSQL_TYPE_GEOMETRY:
			PyErr_SetString(pyMySQL_OperationalError,
							"MYSQL_TYPE_GEOMETRY is unsupported type.");
			break;

		/* NULL type */
		case MYSQL_TYPE_NULL:
			Py_INCREF(Py_None);
			retObj = Py_None;

		default:
			PyErr_SetString(pyMySQL_OperationalError,
							"Unknown type code in query result.");
			break;
	}

	/* Returns the object */
	return retObj;
}
