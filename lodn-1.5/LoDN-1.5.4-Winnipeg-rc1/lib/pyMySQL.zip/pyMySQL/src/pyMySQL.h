
#ifndef PYMYSQL_H_
#define PYMYSQL_H_

#include "Python.h"
#include "mysql.h"

typedef struct
{
    PyObject_HEAD

    /* My data fields */
    MYSQL *conn;

} pyMySQL_ConnectionObject;


typedef struct
{
    PyObject_HEAD

    pyMySQL_ConnectionObject *connObj;

    /* Visable members */
    PyObject *description;			/* Description tuple */
    PyObject *rowcount;				/* Row count */
    PyObject *arraysize;			/* Number of rows for fetchmany */

    /* Internal variables */
    MYSQL_RES *mysqlResultSet;
    unsigned char resultSetFinished;




} pyMySQL_CursorObject;



typedef struct
{
	 PyObject_HEAD

	 /* Internal variables */
	 PyObject *typeCodeList;

} pyMySQL_TypeObject;


extern PyTypeObject pyMySQL_ConnectionType;
extern PyTypeObject pyMySQL_CursorType;
extern PyTypeObject pyMySQL_TypeObjectType;

extern PyObject *pyMySQL_StringTypeObject;
extern PyObject *pyMySQL_BinaryTypeObject;
extern PyObject *pyMySQL_NumberTypeObject;
extern PyObject *pyMySQL_DatetimeTypeObject;
extern PyObject *pyMySQL_RowidTypeObject;


extern PyObject *pyMySQL_Error;
extern PyObject *pyMySQL_Warning;
extern PyObject *pyMySQL_InterfaceError;
extern PyObject *pyMySQL_DatabaseError;
extern PyObject *pyMySQL_InternalError;
extern PyObject *pyMySQL_OperationalError;
extern PyObject *pyMySQL_ProgrammingError;
extern PyObject *pyMySQL_IntegrityError;
extern PyObject *pyMySQL_DataError;
extern PyObject *pyMySQL_NotSupportedError;


void pyMySQL_Errors_init(PyObject *moduleObj);
void pyMySQL_set_exception(MYSQL *conn);
PyObject *pyMySQL_SQLTypeToPyObject(MYSQL_FIELD *field,
							char *data, unsigned long dataLength);

pyMySQL_CursorObject *pyMySQL_CursorObject_NEW(void);
pyMySQL_TypeObject *pyMySQL_TypeObject_New(int *values, int size);

PyObject *pyMySQL_CursorObject_execute(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds);
PyObject *pyMySQL_CursorObject_executemany(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds);
PyObject *pyMySQL_CursorObject_executescript(pyMySQL_CursorObject *self,
												PyObject *args,	PyObject *kwds);
PyObject *pyMySQL_CursorObject_callproc(pyMySQL_CursorObject *self,
										PyObject *args);

PyObject *pyMySQL_Date(PyObject *self, PyObject *args, PyObject *kwargs);
PyObject *pyMySQL_Time(PyObject *self, PyObject *args, PyObject *kwargs);
PyObject *pyMySQL_Datetime(PyObject *self, PyObject *args, PyObject *kwargs);
PyObject *pyMySQL_Timestamp(PyObject *self, PyObject *args, PyObject *kwargs);
PyObject *pyMySQL_DateFromTicks(PyObject *self, PyObject *args, PyObject *kwargs);
PyObject *pyMySQL_TimeFromTicks(PyObject *self, PyObject *args, PyObject *kwargs);
PyObject *pyMySQL_TimestampFromTicks(PyObject *self, PyObject *args, PyObject *kwargs);
PyObject *pyMySQL_Binary(PyObject *self, PyObject *args, PyObject *kwargs);



#endif /* PYMYSQL_H_ */
