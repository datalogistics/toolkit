#include "Python.h"
#include "mysql.h"
#include "mysqld_error.h"


PyObject *pyMySQL_Error				= NULL;
PyObject *pyMySQL_Warning 			= NULL;
PyObject *pyMySQL_InterfaceError 	= NULL;
PyObject *pyMySQL_DatabaseError 	= NULL;
PyObject *pyMySQL_InternalError 	= NULL;
PyObject *pyMySQL_OperationalError 	= NULL;
PyObject *pyMySQL_ProgrammingError 	= NULL;
PyObject *pyMySQL_IntegrityError	= NULL;
PyObject *pyMySQL_DataError 		= NULL;
PyObject *pyMySQL_NotSupportedError = NULL;


void pyMySQL_set_exception(MYSQL *conn)
{
	/* Declarations */
	PyObject *exception;
	PyObject *valueObj;
	unsigned int errno_val;


	errno_val = mysql_errno(conn);

	printf("Errno is %d\n", errno_val);

	switch(errno_val)
	{
		/* Access denied */

		case ER_ACCESS_DENIED_ERROR:
		case ER_TABLE_EXISTS_ERROR:
		/* Duplicate entry */
		case ER_DUP_ENTRY:
			exception = pyMySQL_OperationalError;
			break;

		/* Parse error */
		case ER_PARSE_ERROR:
		case ER_WRONG_VALUE_COUNT_ON_ROW:



		/* No columns defined during table creation */
		case ER_TABLE_MUST_HAVE_COLUMNS:
			exception = pyMySQL_ProgrammingError;
			break;

		/* Default handler for errors */
		default:
			exception = pyMySQL_Error;
	}

	printf("%s:%d\n", __FILE__, __LINE__);


	valueObj = Py_BuildValue("i s", errno_val, mysql_error(conn));

	if(valueObj == NULL)
	{
		PyErr_NoMemory();
		return;
	}


	PyErr_SetObject(exception, valueObj);

	Py_DECREF(valueObj);

	printf("%s:%d\n", __FILE__, __LINE__);
}



void pyMySQL_Errors_init(PyObject *moduleObj)
{
	pyMySQL_Error = PyErr_NewException("pyMySQL.Error", NULL, NULL);
	Py_INCREF(pyMySQL_Error);
	PyModule_AddObject(moduleObj, "Error", pyMySQL_Error);

	pyMySQL_Warning = PyErr_NewException("pyMySQL.Warning", PyExc_Exception, NULL);
	Py_INCREF(pyMySQL_Warning);
	PyModule_AddObject(moduleObj, "Warning", pyMySQL_Warning);

	pyMySQL_InterfaceError = PyErr_NewException("pyMySQL.InterfaceError", pyMySQL_Error, NULL);
	Py_INCREF(pyMySQL_InterfaceError);
	PyModule_AddObject(moduleObj, "InterfaceError", pyMySQL_InterfaceError);

	pyMySQL_DatabaseError = PyErr_NewException("pyMySQL.DatabaseError", pyMySQL_Error, NULL);
	Py_INCREF(pyMySQL_DatabaseError);
	PyModule_AddObject(moduleObj, "DatabaseError", pyMySQL_DatabaseError);

	pyMySQL_InternalError = PyErr_NewException("pyMySQL.InternalError", pyMySQL_DatabaseError, NULL);
	Py_INCREF(pyMySQL_InternalError);
	PyModule_AddObject(moduleObj, "InternalError", pyMySQL_InternalError);

	pyMySQL_OperationalError = PyErr_NewException("pyMySQL.OperationalError", pyMySQL_DatabaseError, NULL);
	Py_INCREF(pyMySQL_OperationalError);
	PyModule_AddObject(moduleObj, "OperationalError", pyMySQL_OperationalError);

	pyMySQL_ProgrammingError = PyErr_NewException("pyMySQL.ProgrammingError", pyMySQL_DatabaseError, NULL);
	Py_INCREF(pyMySQL_ProgrammingError);
	PyModule_AddObject(moduleObj, "ProgrammingError", pyMySQL_ProgrammingError);

	pyMySQL_IntegrityError = PyErr_NewException("pyMySQL.IntegrityError", pyMySQL_DatabaseError, NULL);
	Py_INCREF(pyMySQL_IntegrityError);
	PyModule_AddObject(moduleObj, "IntegrityError", pyMySQL_IntegrityError);

	pyMySQL_DataError = PyErr_NewException("pyMySQL.DataError", pyMySQL_DatabaseError, NULL);
	Py_INCREF(pyMySQL_DataError);
	PyModule_AddObject(moduleObj, "DataError", pyMySQL_DataError);

	pyMySQL_NotSupportedError = PyErr_NewException("pyMySQL.NotSupportedError", pyMySQL_DatabaseError, NULL);
	Py_INCREF(pyMySQL_NotSupportedError);
	PyModule_AddObject(moduleObj, "NotSupportedError", pyMySQL_NotSupportedError);
}
