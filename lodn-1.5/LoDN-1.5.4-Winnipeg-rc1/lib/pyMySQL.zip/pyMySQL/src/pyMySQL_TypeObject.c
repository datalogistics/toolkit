#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Python.h"
#include "pyMySQL.h"


PyObject *pyMySQL_StringTypeObject		= NULL;
PyObject *pyMySQL_BinaryTypeObject		= NULL;
PyObject *pyMySQL_NumberTypeObject		= NULL;
PyObject *pyMySQL_DatetimeTypeObject	= NULL;
PyObject *pyMySQL_RowidTypeObject		= NULL;


static void pyMySQL_TypeObject_dealloc(pyMySQL_TypeObject *self)
{
	if(self->typeCodeList != NULL)
	{
		Py_DECREF(self->typeCodeList);
	}

	/* Frees the object */
	Py_TYPE(self)->tp_free((PyObject*)self);
}



static PyObject *pyMySQL_TypeObject_new(PyTypeObject *type, PyObject *args,
										PyObject *kwds)
{
	/* Declarations */
	pyMySQL_TypeObject *self;


	/* Allocates self */
	self = (pyMySQL_TypeObject*)type->tp_alloc(type, 0);

	if(self != NULL)
	{
		self->typeCodeList = NULL;
	}

	/* Returns the new object */
	return (PyObject*)self;
}



pyMySQL_TypeObject *pyMySQL_TypeObject_New(int *values, int numValues)
{
	/* Declarations */
	pyMySQL_TypeObject *retObj;
	PyObject  *value;
	int i;


	/* Allocates self */
	if((retObj = (pyMySQL_TypeObject*)pyMySQL_TypeObjectType.tp_alloc(
										&pyMySQL_TypeObjectType, 0)) == NULL)
	{
		return NULL;
	}

	/* Creates a tuple to hold the list of type codes */
	if((retObj->typeCodeList = PyTuple_New(numValues)) == NULL)
	{
		Py_DECREF(retObj);
		return NULL;
	}

	/* Inserts each type code as a Python int into the typeCodeTuple */
	for(i=0; i<numValues; i++)
	{
		if((value = PyLong_FromLong(values[i])) == NULL)
		{
			Py_DECREF(retObj->typeCodeList);
			Py_DECREF(retObj);
			return NULL;
		}

		if(PyTuple_SetItem(retObj->typeCodeList, i, value) != 0)
		{
			Py_DECREF(retObj->typeCodeList);
			Py_DECREF(retObj);
			return NULL;
		}
	}

	/* Returns the TypeObject */
	return retObj;
}



static int pyMySQL_TypeObject_init(pyMySQL_TypeObject *self, PyObject *args,
									PyObject *kwds)
{
	/* Declarations */
	PyObject *inputList;
	PyObject *oldList;


	/* Gets the input list argument */
	if(!PyArg_ParseTuple(args, "O", &inputList))
	{
		return -1;
	}

	/* Checks the input is a sequence */
	if(!PySequence_Check(inputList))
	{
		PyErr_SetString(PyExc_TypeError,
							"Argument must support the sequence protocol");
		return -1;
	}

	/* Gets a pointer to the old list */
	oldList = self->typeCodeList;

	/* Creates a tuple of the input sequence */
	if((self->typeCodeList = PySequence_Tuple(inputList)) == NULL)
	{
		self->typeCodeList = oldList;
		return -1;
	}

	/* Frees the old list */
	if(oldList != NULL)
	{
		Py_DECREF(oldList);
	}

	/* Success */
	return 0;
}


static PyObject *PyMySQL_TypeObject_richcmp(pyMySQL_TypeObject *self,
											PyObject *other, int op)
{
	/* Declarations */
	PyObject *retObj = NULL;


	/* Checks that the other object is an int */
	if(!PyLong_Check(other))
	{
		PyErr_SetString(PyExc_TypeError, "In valid type for comparision");
		return NULL;
	}


	/* Which comparision */
	switch(op)
	{
		/* Equal */
		case Py_EQ:

			retObj = (PySequence_Contains(self->typeCodeList, other))
													? Py_True : Py_False;
			break;

		/* Not Equal */
		case Py_NE:

			retObj = (PySequence_Contains(self->typeCodeList, other))
													? Py_False : Py_True;
			break;

		/* Less Than */
		case Py_LT:
			PyErr_SetString(PyExc_TypeError, "Comparision < not supported");
			break;

		/* Less Than or Equal */
		case Py_LE:
			PyErr_SetString(PyExc_TypeError, "Comparision <= not supported");
			break;

		/* Greater Than */
		case Py_GT:
			PyErr_SetString(PyExc_TypeError, "Comparision > not supported");
			break;

		/* Greater Than or Equal */
		case Py_GE:
			PyErr_SetString(PyExc_TypeError, "Comparision >= not supported");
			break;
	}

	/* Increments the reference count on return object */
	Py_XINCREF(retObj);

	/* Return True, False or NULL for error */
	return retObj;
}


PyTypeObject pyMySQL_TypeObjectType =
{
	   PyObject_HEAD_INIT(NULL)
		"pyMSQL.TypeObject",       /* tp_name */
		sizeof(pyMySQL_TypeObject), /* tp_basicsize */
		0,                         /* tp_itemsize */
		(destructor)pyMySQL_TypeObject_dealloc, /* tp_dealloc */
		0,                         /* tp_print */
		0,                         /* tp_getattr */
		0,                         /* tp_setattr */
		0,                         /* tp_reserved */
		0,                         /* tp_repr */
		0,                         /* tp_as_number */
		0,                         /* tp_as_sequence */
		0,                         /* tp_as_mapping */
		0,                         /* tp_hash  */
		0,                         /* tp_call */
		0,                         /* tp_str */
		0,                         /* tp_getattro */
		0,                         /* tp_setattro */
		0,                         /* tp_as_buffer */
		Py_TPFLAGS_DEFAULT |
			Py_TPFLAGS_BASETYPE,   /* tp_flags */
		"TypeObject objects",           /* tp_doc */
		0,		               /* tp_traverse */
		0,		               /* tp_clear */
		(richcmpfunc)PyMySQL_TypeObject_richcmp,  /* tp_richcompare */
		0,		               /* tp_weaklistoffset */
		0,		               /* tp_iter */
		0,		               /* tp_iternext */
		0,             /* tp_methods */
		0,             /* tp_members */
		0,                         /* tp_getset */
		0,                         /* tp_base */
		0,                         /* tp_dict */
		0,                         /* tp_descr_get */
		0,                         /* tp_descr_set */
		0,                         /* tp_dictoffset */
		(initproc)pyMySQL_TypeObject_init,      /* tp_init */
		0,                         /* tp_alloc */
		pyMySQL_TypeObject_new                 /* tp_new */
};

