import os
import re  
import sys
import subprocess
import optparse
from distutils.core import setup, Extension 


parser = optparse.OptionParser()

parser.add_option('--with-mysql', dest='mysql', default=None,
                  help='Path to the mysql installation', 
                  metavar='path-to-mysql|path-to-include,path-to-lib')

options, args = parser.parse_args()


# Gets the path to mysql_config  executable
if options.mysql is None: 
    mysql_config = 'mysql_config'

else:    
    mysql_config = options.mysql + '/bin/mysql_config'
    
    
# Gets the configuration information for mysql
try:
        
    mysql_cflags   = subprocess.getoutput(mysql_config +' --cflags').split()
    mysql_include  = subprocess.getoutput(mysql_config + ' --include').split()
    mysql_libs     = subprocess.getoutput(mysql_config + ' --libs_r').split()
    
except Exception as e:
    sys.exit(e)
 

# For non mac systems, use rpath so that LD_LIBRARY_PATH isn't necessary
if os.uname()[0] != 'Darwin':
 
    for libpath in re.findall('-L(\S+)', ' '.join(mysql_libs)):
        mysql_libs = [ '-Wl,-rpath', '-Wl,'+libpath] + mysql_libs
        
        
# Sets up the defines for mysql
mysql_defines = [('_P1003_1B_VISIBLE', None), ('SIGNAL_WITH_VIO_CLOSE', None), 
                 ('SIGNALS_DONT_BREAK_READ', None), 
                 ('IGNORE_SIGHUP_SIGQUIT', None), 
                 ('DONT_DECLARE_CXA_PURE_VIRTUAL', None)]


pyMySQL = Extension('pyMySQL', 
                    extra_compile_args = mysql_cflags + mysql_include,
                    extra_link_args    = mysql_libs,
                    define_macros = mysql_defines,
                    undef_macros = ['NDEBUG'],
                    export_symbols = ['PyInit_pyMySQL'],
                    sources = ['pyMySQL.c', 'pyMySQL_Connection.c', 
                               'pyMySQL_Cursor.c', 'pyMySQL_TypeAdapter.c', 
                               'pyMySQL_TypeObject.c', 'pyMySQL_Errors.c' ])

setup (name = 'pyMySQL', 
       version = '0.20', 
       description = 'This is python module for pyMySQL.', 
       ext_modules = [pyMySQL],
       script_args = args) 
