#include "Python.h"
#include "structmember.h"
#include "mysql.h"

#include "pyMySQL.h"




static void pyMySQL_ConnectionObject_dealloc(pyMySQL_ConnectionObject *self)
{
	//printf("Freeing connection object\n");

	/* If the connection hasn't already been closed, this closes it */
	if(self->conn != NULL)
	{
		mysql_close(self->conn);
	}

	/* Frees the actual object */
    Py_TYPE(self)->tp_free((PyObject*)self);
}


static PyObject *pyMySQL_ConnectionObject_new(PyTypeObject *type,
												PyObject *args, PyObject *kwds)
{
	/* Declarations */
    pyMySQL_ConnectionObject *self;


    /* Allocates an instance of pyMySQL_ConnectionObject */
    self = (pyMySQL_ConnectionObject*)(type->tp_alloc(type, 0));

    /* Allocation worked, so initialize the variables */
    if(self != NULL)
    {
       self->conn = NULL;
    }

    /* Returns the object */
    return (PyObject*)self;
}



static int pyMySQL_ConnectionObject_init(pyMySQL_ConnectionObject *self,
											PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	MYSQL *conn;
	char *hostname 		= NULL;
	char *username 		= NULL;
	char *passwd 		= NULL;
	char *db_name  		= NULL;
	unsigned int port 	= 0;
	char *unix_socket 	= NULL;
	unsigned long flags = 0;

	my_bool	 true		= 1;


	static char *keywords[] = { "host", "username", "passwd", "db_name",
								"port", "unix_socket", NULL };

	/* Parses the arguments */
	if(!PyArg_ParseTupleAndKeywords(args, kwds, "|ssssIs", keywords,
			&hostname, &username, &passwd, &db_name, &port, &unix_socket))
	{
		return -1;
	}

	/* Creates and initializes a mysql connection */
	if((conn = mysql_init(NULL)) == NULL)
	{
		fprintf(stderr, "mysql_init error\n");
		PyErr_NoMemory();
		return -1;
	}

	/* Makes a connection to the mysql connection */
	if(mysql_real_connect(conn, hostname, username, passwd, db_name, port,
		unix_socket, CLIENT_MULTI_STATEMENTS | CLIENT_MULTI_RESULTS) == NULL)
	{
		fprintf(stderr, "mysql_real_connect error\n");
		goto ERROR_HANDLER;
	}

	/* Sets up reconnection */
	if(mysql_options(conn, MYSQL_OPT_RECONNECT, &true) != 0)
	{
		goto ERROR_HANDLER;
	}

	/* Turns autocommit off */
	if(mysql_autocommit(conn, 0) != 0)
	{
		fprintf(stderr, "mysql_autocommit error\n");
		goto ERROR_HANDLER;
	}

	/* Frees any old connection */
	if(self->conn != NULL)
	{
		mysql_close(self->conn);
		self->conn = NULL;
	}

	/* Assigns the connection */
	self->conn = conn;

	/* Success */
	return 0;


	/* Error handler */
	ERROR_HANDLER:

		/* Free the connection object */
		if(conn != NULL)
		{
			pyMySQL_set_exception(conn);
			mysql_close(conn);
		}

		/* Error occurred */
		return -1;
}


static PyObject *pyMySQL_ConnectionObject_close(pyMySQL_ConnectionObject *self)
{
	/* Closes the connection */
	if(self->conn != NULL)
	{
		mysql_close(self->conn);
		self->conn = NULL;
	}

	/* Returns None */
	Py_RETURN_NONE;
}


static PyObject *pyMySQL_ConnectionObject_commit(pyMySQL_ConnectionObject *self)
{
	/* Declarations */
	MYSQL_RES *result_set;
	PyObject  *errorTuple;

	/* Checks that the connection is still valid */
	if(self->conn == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
							"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Clears the results */
	while(mysql_more_results(self->conn))
	{
		mysql_next_result(self->conn);
		result_set = mysql_use_result(self->conn);

		if(result_set != NULL)
		{
			mysql_free_result(result_set);
		}
	}


	/* Commits the transaction */
	if(mysql_commit(self->conn) != 0)
	{
		pyMySQL_set_exception(self->conn);
		return NULL;
	}

	/* Returns None */
	Py_RETURN_NONE;
}


static PyObject *pyMySQL_ConnectionObject_rollback(pyMySQL_ConnectionObject *self)
{
	/* Declarations */
	PyObject *errorTuple;


	/* Checks that the connection is still valid */
	if(self->conn == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Rolls back the connection */
	if(mysql_rollback(self->conn) != 0)
	{
		pyMySQL_set_exception(self->conn);
		return NULL;
	}

	/* Returns None */
	Py_RETURN_NONE;
}


static PyObject *pyMySQL_ConnectionObject_cursor(pyMySQL_ConnectionObject *self)
{
	/* Declarations */
	pyMySQL_CursorObject *cursorObj;
	PyObject *errorTuple;


	/* Checks that the connection is still valid */
	if(self->conn == NULL)
	{
		if((errorTuple = Py_BuildValue("i s", 0,
				"Cannot operate on a closed database")) == NULL)
		{
			PyErr_NoMemory();
			return NULL;
		}

		PyErr_SetObject(pyMySQL_ProgrammingError, errorTuple);
		Py_DECREF(errorTuple);

		return NULL;
	}

	/* Allocates a cursor object */
	if((cursorObj = pyMySQL_CursorObject_NEW()) == NULL)
	{
		if(PyErr_Occurred()) PyErr_NoMemory();
		return NULL;
	}

	/* Assign the connection to the cursor */
	Py_INCREF(self);
	Py_DECREF(cursorObj->connObj);
	cursorObj->connObj = self;


	/* Returns the cursor object */
	return (PyObject*)cursorObj;
}


static PyObject *pyMySQL_ConnectionObject_execute(pyMySQL_ConnectionObject *self,
								PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	pyMySQL_CursorObject *cursorObj;
	PyObject *retObj;


	/* Allocates a temporary cursor object */
	if((cursorObj = pyMySQL_CursorObject_NEW()) == NULL)
	{
		if(PyErr_Occurred()) PyErr_NoMemory();
		return NULL;
	}

	/* Assign the connection to the cursor */
	Py_INCREF(self);
	Py_DECREF(cursorObj->connObj);
	cursorObj->connObj = self;

	/* Calls the cursors execute command. retobj will either be None for
	 * success or NULL on failure */
	retObj = pyMySQL_CursorObject_execute(cursorObj, args, kwds);

	/* Error checks the return value of the execute method */
	if(retObj == NULL)
	{
		Py_DECREF(cursorObj);
		return NULL;
	}

	/* Frees the temporary cursor */
	Py_DECREF(retObj);

	/* Returns None on success and NULL on failure */
	return (PyObject*)cursorObj;
}


static PyObject *pyMySQL_ConnectionObject_executemany(
		pyMySQL_ConnectionObject *self, PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	pyMySQL_CursorObject *cursorObj;
	PyObject *retObj;


	/* Allocates a temporary cursor object */
	if((cursorObj = pyMySQL_CursorObject_NEW()) == NULL)
	{
		if(PyErr_Occurred()) PyErr_NoMemory();
		return NULL;
	}


	/* Assign the connection to the cursor */
	Py_INCREF(self);
	Py_DECREF(cursorObj->connObj);
	cursorObj->connObj = self;


	/* Calls the cursors execute command. retobj will either be None for
     * success or NULL on failure */
	retObj = pyMySQL_CursorObject_executemany(cursorObj, args, kwds);

	/* Error checks the return value of the execute method */
	if(retObj == NULL)
	{
		Py_DECREF(cursorObj);
		return NULL;
	}

	/* Frees the temporary cursor */
	Py_DECREF(retObj);

	/* Returns None on success and NULL on failure */
	return (PyObject*)cursorObj;
}


static PyObject *pyMySQL_ConnectionObject_executescript(
		pyMySQL_ConnectionObject *self, PyObject *args,	PyObject *kwds)
{
	/* Declarations */
	pyMySQL_CursorObject *cursorObj;
	PyObject *retObj;


	/* Allocates a temporary cursor object */
	if((cursorObj = pyMySQL_CursorObject_NEW()) == NULL)
	{
		if(!PyErr_Occurred()) PyErr_NoMemory();
		return NULL;
	}


	/* Assign the connection to the cursor */
	Py_INCREF(self);
	Py_DECREF(cursorObj->connObj);
	cursorObj->connObj = self;

	/* Calls the cursors execute command. retobj will either be None for
     * success or NULL on failure */
	retObj = pyMySQL_CursorObject_executescript(cursorObj, args, kwds);


	/* Error checks the return value of the execute method */
	if(retObj == NULL)
	{
		Py_DECREF(cursorObj);
		return NULL;
	}

	/* Frees the temporary cursor */
	Py_DECREF(retObj);

	/* Returns None on success and NULL on failure */
	return (PyObject*)cursorObj;
}


static PyObject *pyMySQL_ConnectionObject_callproc(
		pyMySQL_ConnectionObject *self, PyObject *args)
{
	/* Declarations */
	pyMySQL_CursorObject *cursorObj;
	PyObject *retObj;


	/* Allocates a temporary cursor object */
	if((cursorObj = pyMySQL_CursorObject_NEW()) == NULL)
	{
		if(!PyErr_Occurred()) PyErr_NoMemory();
		return NULL;
	}


	/* Assign the connection to the cursor */
	Py_INCREF(self);
	Py_DECREF(cursorObj->connObj);
	cursorObj->connObj = self;

	/* Calls the cursors execute command. retobj will either be None for
     * success or NULL on failure */
	retObj = pyMySQL_CursorObject_callproc(cursorObj, args);


	/* Error checks the return value of the execute method */
	if(retObj == NULL)
	{
		Py_DECREF(cursorObj);
		return NULL;
	}

	/* Frees the temporary cursor */
	Py_DECREF(retObj);

	/* Returns None on success and NULL on failure */
	return (PyObject*)cursorObj;
}


static PyObject *pyMySQL_ConnectionObject___enter__(pyMySQL_ConnectionObject *self,
		PyObject *args, PyObject *kwds)
{
	/* Delcarations */

	/* Increment the reference count on myself */
	Py_INCREF(self);

	/* Return myself */
	return (PyObject *)self;
}



static PyObject *pyMySQL_ConnectionObject___exit__(pyMySQL_ConnectionObject *self,
		PyObject *args, PyObject *kwds)
{
	/* Declarations */
	PyObject *exc_type;
	PyObject *exc_val;
	PyObject *exc_tb;
	PyObject *retObj;


	/* Gets the three objects passed to the method */
	if(!PyArg_ParseTuple(args, "OOO", &exc_type, &exc_val, &exc_tb))
	{
		return NULL;
	}

	/* Success so commit */
	if(exc_type == Py_None && exc_val == Py_None && exc_tb == Py_None)
	{

		retObj = pyMySQL_ConnectionObject_commit(self);

	/* Not successful so rollback changes */
	}else
	{
		if(exc_type == Py_None ||
				!PyErr_GivenExceptionMatches(exc_type, PyExc_BaseException))
		{
			PyErr_SetString(PyExc_TypeError,
					"Invalid first argument to __exit__ of pyMySQL.Connection.__exit__");
			return NULL;

		}else if(exc_tb == Py_None)
		{
			PyErr_SetString(PyExc_TypeError,
				"Invalid second argument to __exit__ of pyMySQL.Connection.__exit__");
			return NULL;
		}

		/* do rollback */
		retObj = pyMySQL_ConnectionObject_rollback(self);
	}

	/* Error has occurred with rollback or commit */
	if(retObj == NULL)
	{
		return NULL;
	}

	/* Decrement the reference count on the return object */
	Py_DECREF(retObj);

	/* Return false to not suppress any exception */
	Py_RETURN_FALSE;
}


static PyMemberDef pyMySQL_ConnectionObject_members[] = {
    {NULL}  /* Sentinel */
};


static PyMethodDef pyMySQL_ConnectionObject_methods[] = {
	{"close", (PyCFunction)pyMySQL_ConnectionObject_close, METH_NOARGS,
			"Closes the connection"},
    {"commit", (PyCFunction)pyMySQL_ConnectionObject_commit, METH_NOARGS,
    		"Commit any pending transaction"},
	{"rollback", (PyCFunction)pyMySQL_ConnectionObject_rollback, METH_NOARGS,
			"Rolls back a transaction"},
	{"cursor", (PyCFunction)pyMySQL_ConnectionObject_cursor, METH_NOARGS,
			"Returns a cursor object"},
	{"execute", (PyCFunction)pyMySQL_ConnectionObject_execute, METH_VARARGS,
			"Prepare and execute a database operation"},
	{"executemany", (PyCFunction)pyMySQL_ConnectionObject_executemany, METH_VARARGS,
			"Prepare and execute a database operation on a sequnce of parameters"},
	{"executescript", (PyCFunction)pyMySQL_ConnectionObject_executescript, METH_VARARGS,
			"Prepare and execute a database script"},
	{"callproc", (PyCFunction)pyMySQL_ConnectionObject_callproc, METH_VARARGS,
			"Prepare and execute a database procedure"},
	{"__enter__", (PyCFunction)pyMySQL_ConnectionObject___enter__, METH_NOARGS,
			"__enter__ method for context manager"},
	{"__exit__", (PyCFunction)pyMySQL_ConnectionObject___exit__, METH_VARARGS,
			"__exit__ method for context manager"},
    {NULL}  /* Sentinel */
};



PyTypeObject pyMySQL_ConnectionType = {
    PyObject_HEAD_INIT(NULL)
    "pyMySQL.Connection",             /* tp_name */
    sizeof(pyMySQL_ConnectionObject), /* tp_basicsize */
    0,                         /* tp_itemsize */
    (destructor)pyMySQL_ConnectionObject_dealloc, /* tp_dealloc */
    0,                         /* tp_print */
    0,                         /* tp_getattr */
    0,                         /* tp_setattr */
    0,                         /* tp_reserved */
    0,                         /* tp_repr */
    0,                         /* tp_as_number */
    0,                         /* tp_as_sequence */
    0,                         /* tp_as_mapping */
    0,                         /* tp_hash  */
    0,                         /* tp_call */
    0,                         /* tp_str */
    0,                         /* tp_getattro */
    0,                         /* tp_setattro */
    0,                         /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT |
		Py_TPFLAGS_BASETYPE,   /* tp_flags */
    NULL,           /* tp_doc */
    0,		               /* tp_traverse */
    0,		               /* tp_clear */
    0,		               /* tp_richcompare */
    0,		               /* tp_weaklistoffset */
    0,		               /* tp_iter */
    0,		               /* tp_iternext */
    pyMySQL_ConnectionObject_methods,             /* tp_methods */
    pyMySQL_ConnectionObject_members,             /* tp_members */
    0,                         /* tp_getset */
    0,                         /* tp_base */
    0,                         /* tp_dict */
    0,                         /* tp_descr_get */
    0,                         /* tp_descr_set */
    0,                         /* tp_dictoffset */
    (initproc)pyMySQL_ConnectionObject_init,      /* tp_init */
    0,                         					  /* tp_alloc */
    pyMySQL_ConnectionObject_new,                 /* tp_new */
};
