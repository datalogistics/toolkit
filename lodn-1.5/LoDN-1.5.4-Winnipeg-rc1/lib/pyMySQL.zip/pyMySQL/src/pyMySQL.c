
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

#include "Python.h"
#include "structmember.h"
#include "datetime.h"

#include "mysql.h"

#include "pyMySQL.h"







static PyObject *pyMySQL_connect(PyObject *self, PyObject *args, PyObject *kwargs)
{
	/* Declarations */
	PyObject *connectObj;


	/* Creates an connection object */
	if((connectObj = pyMySQL_ConnectionType.tp_new(&pyMySQL_ConnectionType,
													NULL, NULL)) == NULL)
	{
		return PyErr_NoMemory();
	}

	/* Initializes the connection object */
	if(pyMySQL_ConnectionType.tp_init(connectObj, args, kwargs) != 0)
	{
		Py_DECREF(connectObj);
		return NULL;
	}

	/* Return the object with the reference count increased */
	return connectObj;
}


/* Methods for pyMySQL */
static PyMethodDef pyMySQL_methods[] = {

    {"connect",  (PyCFunction)pyMySQL_connect, METH_VARARGS | METH_KEYWORDS, ""},

    {"Date",  (PyCFunction)pyMySQL_Date, METH_VARARGS, ""},
    {"Datetime",  (PyCFunction)pyMySQL_Datetime, METH_VARARGS, ""},
    {"Time",  (PyCFunction)pyMySQL_Time, METH_VARARGS, ""},
    {"Timestamp",  (PyCFunction)pyMySQL_Timestamp, METH_VARARGS, ""},
    {"DateFromTicks",  (PyCFunction)pyMySQL_DateFromTicks, METH_VARARGS, ""},
    {"TimeFromTicks",  (PyCFunction)pyMySQL_TimeFromTicks, METH_VARARGS, ""},
    {"TimestampFromTicks",  (PyCFunction)pyMySQL_TimestampFromTicks, METH_VARARGS, ""},
    {"Binary",  (PyCFunction)pyMySQL_Binary, METH_VARARGS, ""},


    {NULL, NULL, 0, NULL}        /* Sentinel */
};



/* Module table */
static struct PyModuleDef pyMySQL_module = {

   PyModuleDef_HEAD_INIT,
   "pyMySQL",   			/* name of module */
   NULL, 					/* module documentation */
   -1,
   pyMySQL_methods
};


static int pyMySQL_mysql_init(void)
{
	if(mysql_library_init(0, NULL, NULL) != 0)
	{
		PyErr_SetString(pyMySQL_OperationalError, "Error intializing mysql");
		return -1;
	}

	/*if(!mysql_thread_safe())
	{
		printf("here\n");
		PyErr_SetString(pyMySQL_Warning, "Error intializing mysql");
		return -1;
	}*/


	return 0;
}


PyMODINIT_FUNC PyInit_pyMySQL(void)
{
	/* Declarations */
	PyObject *moduleObj;


	/* Initializes the mysql library */
	if(pyMySQL_mysql_init() != 0)
	{
		return NULL;
	}

	/* Creates the module */
	if((moduleObj = PyModule_Create(&pyMySQL_module)) == NULL)
	{
		return NULL;
	}

	/* Adds constants to the module */
	if(PyModule_AddStringConstant(moduleObj, "apilevel", "2.0") != 0)
	{
		return NULL;
	}

	if(PyModule_AddIntConstant(moduleObj, "threadsafety", 1) != 0)
	{
		return NULL;
	}

	if(PyModule_AddStringConstant(moduleObj, "paramstyle", "qmark") != 0)
	{
		return NULL;
	}


	/* Readies the type */
	//pyMySQL_ConnectionType.tp_new = PyType_GenericNew;
	if(PyType_Ready(&pyMySQL_ConnectionType) < 0)
	{
	    return NULL;
	}

	if(PyType_Ready(&pyMySQL_CursorType) < 0)
	{
		return NULL;
	}



	if(PyType_Ready(&pyMySQL_TypeObjectType) < 0)
	{
		return NULL;
	}



	/* Adds the types to the modules */
	Py_INCREF(&pyMySQL_ConnectionType);
	PyModule_AddObject(moduleObj, "Connection",
			(PyObject *)&pyMySQL_ConnectionType);

	Py_INCREF(&pyMySQL_CursorType);
	PyModule_AddObject(moduleObj, "Cursor",
				(PyObject *)&pyMySQL_CursorType);

	Py_INCREF(&pyMySQL_TypeObjectType);
	PyModule_AddObject(moduleObj, "TypeObject",
					(PyObject *)&pyMySQL_TypeObjectType);


	/*		STRING

	            This type object is used to describe columns in a database
	            that are string-based (e.g. CHAR).

	        BINARY

	            This type object is used to describe (long) binary columns
	            in a database (e.g. LONG, RAW, BLOBs).



	        DATETIME

	            This type object is used to describe date/time columns in
	            a database.

			NUMBER

	            This type object is used to describe numeric columns in a
	            database.

	        ROWID

	            This type object is used to describe the "Row ID" column
	            in a database.
	            */

	int stringTypeCodes[] = {  MYSQL_TYPE_STRING, MYSQL_TYPE_VAR_STRING };
	int binaryTypeCodes[] = {  MYSQL_TYPE_BLOB };
	int datetimeTypeCodes[] = { MYSQL_TYPE_DATE, MYSQL_TYPE_TIME,
								MYSQL_TYPE_DATETIME, MYSQL_TYPE_TIMESTAMP,
								MYSQL_TYPE_YEAR};
	int numberTypeCodes[] = { MYSQL_TYPE_TINY, MYSQL_TYPE_SHORT, MYSQL_TYPE_LONG,
			MYSQL_TYPE_INT24, MYSQL_TYPE_LONGLONG, MYSQL_TYPE_DECIMAL,
			MYSQL_TYPE_NEWDECIMAL, MYSQL_TYPE_FLOAT, MYSQL_TYPE_DOUBLE };
	int rowidTypeCodes[]  = { MYSQL_TYPE_LONG };


	pyMySQL_StringTypeObject = pyMySQL_TypeObject_New(stringTypeCodes,
										(int)sizeof(stringTypeCodes)/sizeof(int));

	PyModule_AddObject(moduleObj, "STRING", pyMySQL_StringTypeObject);


	pyMySQL_BinaryTypeObject = pyMySQL_TypeObject_New(binaryTypeCodes,
											sizeof(binaryTypeCodes)/sizeof(int));

	PyModule_AddObject(moduleObj, "BINARY", pyMySQL_BinaryTypeObject);


	pyMySQL_NumberTypeObject = pyMySQL_TypeObject_New(
						numberTypeCodes, sizeof(numberTypeCodes)/sizeof(int));

	PyModule_AddObject(moduleObj, "NUMBER", pyMySQL_NumberTypeObject);

	pyMySQL_DatetimeTypeObject = pyMySQL_TypeObject_New(
						datetimeTypeCodes, sizeof(datetimeTypeCodes)/sizeof(int));

	PyModule_AddObject(moduleObj, "DATETIME", pyMySQL_DatetimeTypeObject);

	pyMySQL_RowidTypeObject = pyMySQL_TypeObject_New(rowidTypeCodes,
											sizeof(rowidTypeCodes)/sizeof(int));

	PyModule_AddObject(moduleObj, "ROWID", pyMySQL_RowidTypeObject);

	/*
	 *
	 *
	 *
	 *
	PyDateTime_IMPORT;



	PyTypeObject *pyMySQL_STRING	= &PyUnicode_Type;
	PyTypeObject *pyMySQL_BINARY	= &PyBytes_Type;
	PyTypeObject *pyMySQL_DATETIME  = PyDateTimeAPI->DateTimeType;

	Py_INCREF(pyMySQL_STRING);
	PyModule_AddObject(moduleObj, "STRING",
					(PyObject *)pyMySQL_STRING);

	Py_INCREF(pyMySQL_BINARY);
	PyModule_AddObject(moduleObj, "BINARY",
					(PyObject *)pyMySQL_BINARY);



	Py_INCREF(pyMySQL_DATETIME);
	PyModule_AddObject(moduleObj, "DATETIME",
					(PyObject *)pyMySQL_DATETIME);*/

	/* Adds the exceptions */
	pyMySQL_Errors_init(moduleObj);




	/* Returns the module */
	return moduleObj;
}

