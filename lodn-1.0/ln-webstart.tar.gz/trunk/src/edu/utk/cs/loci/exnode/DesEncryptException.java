package edu.utk.cs.loci.exnode;

public class DesEncryptException extends Exception
{

    public DesEncryptException()
    {
        super();
    }

    public DesEncryptException( String msg )
    {
        super( msg );
    }
}