package edu.utk.cs.loci.exnode;

public class AesEncryptException extends Exception
{

    public AesEncryptException()
    {
        super();
    }

    public AesEncryptException( String msg )
    {
        super( msg );
    }
}