<?xml version="1.0" encoding="ISO-8859-1" ?>
<helpset version="2.0">
	<title>LoDN Client - Help</title>
	<maps>
		<homeID>intro</homeID>
		<mapref location="map.jhm"/>
	</maps>
	<view xml:lang="en-US" mergetype="javax.help.NoMerge">
		<name>TOC</name>
		<label>Table of Contents</label>
		<type>javax.help.TOCView</type>
		<data>toc.xml</data>
	</view>
</helpset>
