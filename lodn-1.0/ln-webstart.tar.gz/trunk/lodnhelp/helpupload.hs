<?xml version="1.0" encoding="ISO-8859-1" ?>
<helpset version="2.0">
	<title>LoDN Publisher Upload Client - Help</title>
	<maps>
		<homeID>upload</homeID>
		<mapref location="mapupload.jhm"/>
	</maps>
	<view xml:lang="en-US" mergetype="javax.help.NoMerge">
		<name>TOC</name>
		<label>Table of Contents</label>
		<type>javax.help.TOCView</type>
		<data>tocupload.xml</data>
	</view>
</helpset>
